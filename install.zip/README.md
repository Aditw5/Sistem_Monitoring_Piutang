## <center>**WA Lazy - WALIX</center>

**WA Lazy** WA Lazy is a whatsapp gateway application that allows us to send whatsapp messages through the website, using Api. there are several other features in WA Lazy such as Broadcast, Campaign, Rest Api, Auto Responder
<br>

```php
# system requirements
- PHP 8.1 or higher
- MySQL 5.7 or higher
- Web Server (Apache)
- NodeJS 14 or higher (16.16.0 recommended)
```


