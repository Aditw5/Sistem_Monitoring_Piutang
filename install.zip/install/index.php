<?php
// redirect step1
header("Location: one");
